const { Calculator } =  require('./Calculator');

module.exports = {
    Calculator
}; 